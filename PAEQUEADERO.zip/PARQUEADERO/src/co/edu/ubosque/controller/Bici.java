package co.edu.ubosque.controller;

import co.edu.ubosque.model.BiciDTO;
import co.edu.unbosque.model.persistence.BiciDAO;
import co.edu.unbosque.util.structure.Node;

public class Bici {

    private BiciDAO biciDAO;

    public Bici() {
        biciDAO = new BiciDAO();
    }

    public void agregarBici(BiciDTO bici) {
        biciDAO.crear(bici);
    }

    public boolean eliminarBici(int posicion) {
        return biciDAO.eliminar(posicion);
    }

    public boolean actualizarBici(int posicion, BiciDTO nuevaBici) {
        return biciDAO.actualizar(posicion, nuevaBici);
    }

    public String mostrarBicis() {
        return biciDAO.mostrar();
    }

    public BiciDTO obtenerBici(int posicion) {
        if (posicion < 0 || posicion >= biciDAO.size()) {
            return null;
        }
        Node<BiciDTO> nodo = biciDAO.getNode(posicion);
        return nodo != null ? nodo.getInfo() : null;
    }
}
