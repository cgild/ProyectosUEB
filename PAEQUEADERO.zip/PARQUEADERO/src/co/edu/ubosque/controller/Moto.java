package co.edu.ubosque.controller;

import co.edu.ubosque.model.MotoDTO;
import co.edu.unbosque.model.persistence.MotoDAO;
import co.edu.unbosque.util.structure.Node;

public class Moto {

    private MotoDAO motoDAO;

    public Moto() {
        motoDAO = new MotoDAO();
    }

    public void agregarMoto(MotoDTO moto) {
        motoDAO.crear(moto);
    }

    public boolean eliminarMoto(int posicion) {
        return motoDAO.eliminar(posicion);
    }

    public boolean actualizarMoto(int posicion, MotoDTO nuevaMoto) {
        return motoDAO.actualizar(posicion, nuevaMoto);
    }

    public String mostrarMotos() {
        return motoDAO.mostrar();
    }

    public MotoDTO obtenerMoto(int posicion) {
        if (posicion < 0 || posicion >= motoDAO.size()) {
            return null;
        }
        Node<MotoDTO> nodo = motoDAO.getNode(posicion);
        return nodo != null ? nodo.getInfo() : null;
    }
}
