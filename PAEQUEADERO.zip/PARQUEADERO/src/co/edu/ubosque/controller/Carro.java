package co.edu.ubosque.controller;

import co.edu.ubosque.model.CarroDTO;
import co.edu.unbosque.model.persistence.CarroDAO;
import co.edu.unbosque.util.structure.Node;

public class Carro {

    private CarroDAO carroDAO;

    public Carro() {
        carroDAO = new CarroDAO();
    }

    public void agregarCarro(CarroDTO carro) {
        carroDAO.crear(carro);
    }

    public boolean eliminarCarro(int posicion) {
        return carroDAO.eliminar(posicion);
    }

    public boolean actualizarCarro(int posicion, CarroDTO nuevoCarro) {
        return carroDAO.actualizar(posicion, nuevoCarro);
    }

    public String mostrarCarros() {
        return carroDAO.mostrar();
    }

    public CarroDTO obtenerCarro(int posicion) {
        if (posicion < 0 || posicion >= carroDAO.size()) {
            return null;
        }
        Node<CarroDTO> nodo = carroDAO.getNode(posicion);
        return nodo != null ? nodo.getInfo() : null;
    }
}
