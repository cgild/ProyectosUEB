package co.edu.ubosque.model;

public class BiciDTO extends ConductorDTO{
	
	private boolean tieneCanasta;
	private int numPedales;
	private int numRuedas;
	private int numAsientos;
	private float pesoDeLaBici;
	
	public BiciDTO() {
	}

	public BiciDTO(boolean tieneCanasta, int numPedales, int numRuedas, int numAsientos, float pesoDeLaBici) {
		super();
		this.tieneCanasta = tieneCanasta;
		this.numPedales = numPedales;
		this.numRuedas = numRuedas;
		this.numAsientos = numAsientos;
		this.pesoDeLaBici = pesoDeLaBici;
	}

	public BiciDTO(String nombreDelConductor, int cedulaDelConductor) {
		super(nombreDelConductor, cedulaDelConductor);
		// TODO Auto-generated constructor stub
	}

	public BiciDTO(String nombreDelConductor, int cedulaDelConductor, boolean tieneCanasta, int numPedales,
			int numRuedas, int numAsientos, float pesoDeLaBici) {
		super(nombreDelConductor, cedulaDelConductor);
		this.tieneCanasta = tieneCanasta;
		this.numPedales = numPedales;
		this.numRuedas = numRuedas;
		this.numAsientos = numAsientos;
		this.pesoDeLaBici = pesoDeLaBici;
	}

	public boolean isTieneCanasta() {
		return tieneCanasta;
	}

	public void setTieneCanasta(boolean tieneCanasta) {
		this.tieneCanasta = tieneCanasta;
	}

	public int getNumPedales() {
		return numPedales;
	}

	public void setNumPedales(int numPedales) {
		this.numPedales = numPedales;
	}

	public int getNumRuedas() {
		return numRuedas;
	}

	public void setNumRuedas(int numRuedas) {
		this.numRuedas = numRuedas;
	}

	public int getNumAsientos() {
		return numAsientos;
	}

	public void setNumAsientos(int numAsientos) {
		this.numAsientos = numAsientos;
	}

	public float getPesoDeLaBici() {
		return pesoDeLaBici;
	}

	public void setPesoDeLaBici(float pesoDeLaBici) {
		this.pesoDeLaBici = pesoDeLaBici;
	}

	@Override
	public String toString() {
		return "Tiene Canasta: " + tieneCanasta + "\n Número de Pedales: " + numPedales + "\n Número de Ruedas: " + numRuedas
				+ "\n Número de Asientos: " + numAsientos + "\n Peso de la Bicicleta: " + pesoDeLaBici + "\n";
	}
}
