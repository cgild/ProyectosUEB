package co.edu.ubosque.model;

public class MotoDTO extends ConductorDTO{
	
	private int cilindraje;
	private boolean tieneParrila;
	private String tipoDeSillon;
	private int tamanio;
	private String placa;
	
	public MotoDTO() {
	}

	public MotoDTO(int cilindraje, boolean tieneParrila, String tipoDeSillon, int tamanio, String placa) {
		super();
		this.cilindraje = cilindraje;
		this.tieneParrila = tieneParrila;
		this.tipoDeSillon = tipoDeSillon;
		this.tamanio = tamanio;
		this.placa = placa;
	}

	public MotoDTO(String nombreDelConductor, int cedulaDelConductor, int cilindraje, boolean tieneParrila,
			String tipoDeSillon, int tamanio, String placa) {
		super(nombreDelConductor, cedulaDelConductor);
		this.cilindraje = cilindraje;
		this.tieneParrila = tieneParrila;
		this.tipoDeSillon = tipoDeSillon;
		this.tamanio = tamanio;
		this.placa = placa;
	}

	public MotoDTO(String nombreDelConductor, int cedulaDelConductor) {
		super(nombreDelConductor, cedulaDelConductor);
		// TODO Auto-generated constructor stub
	}

	public int getCilindraje() {
		return cilindraje;
	}

	public void setCilindraje(int cilindraje) {
		this.cilindraje = cilindraje;
	}

	public boolean isTieneParrila() {
		return tieneParrila;
	}

	public void setTieneParrila(boolean tieneParrila) {
		this.tieneParrila = tieneParrila;
	}

	public String getTipoDeSillon() {
		return tipoDeSillon;
	}

	public void setTipoDeSillon(String tipoDeSillon) {
		this.tipoDeSillon = tipoDeSillon;
	}

	public int getTamanio() {
		return tamanio;
	}

	public void setTamanio(int tamanio) {
		this.tamanio = tamanio;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	@Override
	public String toString() {
		return "Cilindraje: " + cilindraje + "\n Tiene Parrila: " + tieneParrila + "\n Tipo de Sillon: " + tipoDeSillon
				+ "\n Tamaño: " + tamanio + "\n Placa: " + placa + "\n";
	}
}
