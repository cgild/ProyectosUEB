package co.edu.ubosque.model;

public class CarroDTO extends ConductorDTO{
	
	private String marcaRadio;
	private String modelo;
	private String marca;
	private String placa;
	private int tamanio;
	
	public CarroDTO() {
	}

	public CarroDTO(String marcaRadio, String modelo, String marca, String placa, int tamanio) {
		super();
		this.marcaRadio = marcaRadio;
		this.modelo = modelo;
		this.marca = marca;
		this.placa = placa;
		this.tamanio = tamanio;
	}

	public CarroDTO(String nombreDelConductor, int cedulaDelConductor, String marcaRadio, String modelo, String marca,
			String placa, int tamanio) {
		super(nombreDelConductor, cedulaDelConductor);
		this.marcaRadio = marcaRadio;
		this.modelo = modelo;
		this.marca = marca;
		this.placa = placa;
		this.tamanio = tamanio;
	}

	public CarroDTO(String nombreDelConductor, int cedulaDelConductor) {
		super(nombreDelConductor, cedulaDelConductor);
	}

	public String getMarcaRadio() {
		return marcaRadio;
	}

	public void setMarcaRadio(String marcaRadio) {
		this.marcaRadio = marcaRadio;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public int getTamanio() {
		return tamanio;
	}

	public void setTamanio(int tamanio) {
		this.tamanio = tamanio;
	}

	@Override
	public String toString() {
		return "Marca Radio: " + marcaRadio + "\n Modelo: " + modelo + "\n Marca: " + marca + "\n Placa: " + placa
				+ "\n Tamaño: " + tamanio + "\n";
	}
}
