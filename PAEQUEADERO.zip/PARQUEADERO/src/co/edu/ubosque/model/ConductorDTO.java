package co.edu.ubosque.model;

public class ConductorDTO {
	
	private String nombreDelConductor;
	private int cedulaDelConductor;
	
	public ConductorDTO() {
		// TODO Auto-generated constructor stub
	}

	public ConductorDTO(String nombreDelConductor, int cedulaDelConductor) {
		super();
		this.nombreDelConductor = nombreDelConductor;
		this.cedulaDelConductor = cedulaDelConductor;
	}

	public String getNombreDelConductor() {
		return nombreDelConductor;
	}

	public void setNombreDelConductor(String nombreDelConductor) {
		this.nombreDelConductor = nombreDelConductor;
	}

	public int getCedulaDelConductor() {
		return cedulaDelConductor;
	}

	public void setCedulaDelConductor(int cedulaDelConductor) {
		this.cedulaDelConductor = cedulaDelConductor;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Nombre Del Conductor: " + nombreDelConductor + "\n Cédula Del Conductor" + cedulaDelConductor + "\n";
	}
}
