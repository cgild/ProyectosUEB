package co.edu.unbosque.view;

import co.edu.ubosque.model.BiciDTO;
import co.edu.ubosque.model.CarroDTO;
import co.edu.ubosque.model.MotoDTO;
import co.edu.unbosque.model.persistence.BiciDAO;
import co.edu.unbosque.model.persistence.CarroDAO;
import co.edu.unbosque.model.persistence.MotoDAO;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Console {

    private static final int AGREGAR_CARRO = 1;
    private static final int AGREGAR_BICI = 2;
    private static final int AGREGAR_MOTO = 3;
    private static final int EDITAR_VEHICULO = 4;
    private static final int ELIMINAR_VEHICULO = 5;
    private static final int MOSTRAR_TODOS = 6;
    private static final int SALIR = 7;

    private CarroDAO carroDAO;
    private BiciDAO biciDAO;
    private MotoDAO motoDAO;

    private Scanner scanner;

    public Console() {
        carroDAO = new CarroDAO();
        biciDAO = new BiciDAO();
        motoDAO = new MotoDAO();
        scanner = new Scanner(System.in);
        menu();
    }

    public void menu() {
        while (true) {
            try {
                mostrarMenu();
                int option = scanner.nextInt();

                switch (option) {
                    case AGREGAR_CARRO:
                        agregarCarro();
                        break;
                    case AGREGAR_BICI:
                        agregarBici();
                        break;
                    case AGREGAR_MOTO:
                        agregarMoto();
                        break;
                    case EDITAR_VEHICULO:
                        editarVehiculo();
                        break;
                    case ELIMINAR_VEHICULO:
                        eliminarVehiculo();
                        break;
                    case MOSTRAR_TODOS:
                        mostrarTodos();
                        break;
                    case SALIR:
                        System.out.println("Saliendo...");
                        return;
                    default:
                        System.out.println("Opción no válida. Por favor intente nuevamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor ingrese un número.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }

    private void mostrarMenu() {
        System.out.println("\n--- Administración de Vehículos ---");
        System.out.println(AGREGAR_CARRO + ". Agregar Carro");
        System.out.println(AGREGAR_BICI + ". Agregar Bici");
        System.out.println(AGREGAR_MOTO + ". Agregar Moto");
        System.out.println(EDITAR_VEHICULO + ". Editar Vehículo");
        System.out.println(ELIMINAR_VEHICULO + ". Eliminar Vehículo");
        System.out.println(MOSTRAR_TODOS + ". Mostrar Todos");
        System.out.println(SALIR + ". Salir");
        System.out.print("Seleccione una opción: ");
    }

    private void agregarCarro() {
        scanner.nextLine(); // Consume newline
        System.out.print("Nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Cédula del conductor: ");
        int cedula = leerEntero();
        System.out.print("Marca del radio: ");
        String marcaRadio = scanner.nextLine();
        System.out.print("Modelo del carro: ");
        String modelo = scanner.nextLine();
        System.out.print("Marca del carro: ");
        String marca = scanner.nextLine();
        System.out.print("Placa del carro: ");
        String placa = scanner.nextLine();
        System.out.print("Tamaño del carro: ");
        int tamanio = leerEntero();

        CarroDTO nuevoCarro = new CarroDTO(nombre, cedula, marcaRadio, modelo, marca, placa, tamanio);
        carroDAO.crear(nuevoCarro);
        System.out.println("Carro agregado exitosamente.");
    }

    private void agregarBici() {
        scanner.nextLine(); // Consume newline
        System.out.print("Nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Cédula del conductor: ");
        int cedula = leerEntero();
        System.out.print("¿Tiene canasta? (true/false): ");
        boolean tieneCanasta = leerBooleano();
        System.out.print("Número de pedales: ");
        int numPedales = leerEntero();
        System.out.print("Número de ruedas: ");
        int numRuedas = leerEntero();
        System.out.print("Número de asientos: ");
        int numAsientos = leerEntero();
        System.out.print("Peso de la bicicleta: ");
        float pesoDeLaBici = leerFloat();

        BiciDTO nuevaBici = new BiciDTO(nombre, cedula, tieneCanasta, numPedales, numRuedas, numAsientos, pesoDeLaBici);
        biciDAO.crear(nuevaBici);
        System.out.println("Bicicleta agregada exitosamente.");
    }

    private void agregarMoto() {
        scanner.nextLine(); // Consume newline
        System.out.print("Nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Cédula del conductor: ");
        int cedula = leerEntero();
        System.out.print("Cilindraje de la moto: ");
        int cilindraje = leerEntero();
        System.out.print("¿Tiene parrilla? (true/false): ");
        boolean tieneParrilla = leerBooleano();
        System.out.print("Tipo de sillón: ");
        String tipoDeSillon = scanner.nextLine();
        System.out.print("Tamaño de la moto: ");
        int tamanio = leerEntero();
        System.out.print("Placa de la moto: ");
        String placa = scanner.nextLine();

        MotoDTO nuevaMoto = new MotoDTO(nombre, cedula, cilindraje, tieneParrilla, tipoDeSillon, tamanio, placa);
        motoDAO.crear(nuevaMoto);
        System.out.println("Moto agregada exitosamente.");
    }

    private void editarVehiculo() {
        scanner.nextLine(); // Consume newline
        System.out.print("Tipo de vehículo a editar (Carro/Bici/Moto): ");
        String tipoVehiculo = scanner.nextLine().toLowerCase();
        System.out.print("Posición del vehículo a editar: ");
        int posicion = leerEntero();

        switch (tipoVehiculo) {
            case "carro":
                editarCarro(posicion);
                break;
            case "bici":
                editarBici(posicion);
                break;
            case "moto":
                editarMoto(posicion);
                break;
            default:
                System.out.println("Tipo de vehículo no reconocido.");
        }
    }

    private void editarCarro(int posicion) {
        scanner.nextLine(); // Consume newline
        System.out.print("Nuevo nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva cédula del conductor: ");
        int cedula = leerEntero();
        System.out.print("Nueva marca del radio: ");
        String marcaRadio = scanner.nextLine();
        System.out.print("Nuevo modelo del carro: ");
        String modelo = scanner.nextLine();
        System.out.print("Nueva marca del carro: ");
        String marca = scanner.nextLine();
        System.out.print("Nueva placa del carro: ");
        String placa = scanner.nextLine();
        System.out.print("Nuevo tamaño del carro: ");
        int tamanio = leerEntero();

        CarroDTO carroActualizado = new CarroDTO(nombre, cedula, marcaRadio, modelo, marca, placa, tamanio);
        carroDAO.actualizar(posicion, carroActualizado);
        System.out.println("Carro actualizado exitosamente.");
    }

    private void editarBici(int posicion) {
        scanner.nextLine(); // Consume newline
        System.out.print("Nuevo nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva cédula del conductor: ");
        int cedula = leerEntero();
        System.out.print("¿Tiene canasta? (true/false): ");
        boolean tieneCanasta = leerBooleano();
        System.out.print("Nuevo número de pedales: ");
        int numPedales = leerEntero();
        System.out.print("Nuevo número de ruedas: ");
        int numRuedas = leerEntero();
        System.out.print("Nuevo número de asientos: ");
        int numAsientos = leerEntero();
        System.out.print("Nuevo peso de la bicicleta: ");
        float pesoDeLaBici = leerFloat();

        BiciDTO biciActualizada = new BiciDTO(nombre, cedula, tieneCanasta, numPedales, numRuedas, numAsientos, pesoDeLaBici);
        biciDAO.actualizar(posicion, biciActualizada);
        System.out.println("Bicicleta actualizada exitosamente.");
    }

    private void editarMoto(int posicion) {
        scanner.nextLine(); // Consume newline
        System.out.print("Nuevo nombre del conductor: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva cédula del conductor: ");
        int cedula = leerEntero();
        System.out.print("Nuevo cilindraje de la moto: ");
        int cilindraje = leerEntero();
        System.out.print("¿Tiene parrilla? (true/false): ");
        boolean tieneParrilla = leerBooleano();
        System.out.print("Nuevo tipo de sillón: ");
        String tipoDeSillon = scanner.nextLine();
        System.out.print("Nuevo tamaño de la moto: ");
        int tamanio = leerEntero();
        System.out.print("Nueva placa de la moto: ");
        String placa = scanner.nextLine();

        MotoDTO motoActualizada = new MotoDTO(nombre, cedula, cilindraje, tieneParrilla, tipoDeSillon, tamanio, placa);
        motoDAO.actualizar(posicion, motoActualizada);
        System.out.println("Moto actualizada exitosamente.");
    }

    private void eliminarVehiculo() {
        scanner.nextLine(); // Consume newline
        System.out.print("Tipo de vehículo a eliminar (Carro/Bici/Moto): ");
        String tipoVehiculo = scanner.nextLine().toLowerCase();
        System.out.print("Posición del vehículo a eliminar: ");
        int posicion = leerEntero();

        boolean resultado = false;
        switch (tipoVehiculo) {
            case "carro":
                resultado = carroDAO.eliminar(posicion);
                break;
            case "bici":
                resultado = biciDAO.eliminar(posicion);
                break;
            case "moto":
                resultado = motoDAO.eliminar(posicion);
                break;
            default:
                System.out.println("Tipo de vehículo no reconocido.");
                return;
        }

        if (resultado) {
            System.out.println("Vehículo eliminado exitosamente.");
        } else {
            System.out.println("Error al eliminar el vehículo. Verifique la posición.");
        }
    }

    private void mostrarTodos() {
        System.out.println("Carros:");
        System.out.println(carroDAO.mostrar());
        System.out.println("Bicicletas:");
        System.out.println(biciDAO.mostrar());
        System.out.println("Motos:");
        System.out.println(motoDAO.mostrar());
    }

    private int leerEntero() {
        while (true) {
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor ingrese un número entero.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }

    private float leerFloat() {
        while (true) {
            try {
                return scanner.nextFloat();
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor ingrese un número decimal.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }

    private boolean leerBooleano() {
        while (true) {
            try {
                return scanner.nextBoolean();
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor ingrese true o false.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }

    public static void main(String[] args) {
        new Console();
    }
}
