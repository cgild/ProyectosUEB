package co.edu.unbosque.view;

import co.edu.ubosque.model.BiciDTO;
import co.edu.ubosque.model.CarroDTO;
import co.edu.ubosque.model.MotoDTO;
import co.edu.unbosque.model.persistence.BiciDAO;
import co.edu.unbosque.model.persistence.CarroDAO;
import co.edu.unbosque.model.persistence.MotoDAO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainView extends JFrame {

    private CarroDAO carroDAO;
    private BiciDAO biciDAO;
    private MotoDAO motoDAO;

    private JTextArea displayArea;

    public MainView() {
        carroDAO = new CarroDAO();
        biciDAO = new BiciDAO();
        motoDAO = new MotoDAO();

        setTitle("Vehicle Management");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initializeGUI();
    }

    private void initializeGUI() {
        // Panel principal
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(Color.LIGHT_GRAY);
        
        // Título
        JLabel titleLabel = new JLabel("Administración de Vehículos", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.DARK_GRAY);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Panel de botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(7, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        buttonPanel.setBackground(Color.LIGHT_GRAY);

        // Botones del menú
        JButton addCarButton = createButton("Agregar Carro", Color.CYAN);
        JButton addBikeButton = createButton("Agregar Bici", Color.PINK);
        JButton addMotoButton = createButton("Agregar Moto", Color.ORANGE);
        JButton editVehicleButton = createButton("Editar Vehículo", Color.YELLOW);
        JButton deleteVehicleButton = createButton("Eliminar Vehículo", Color.RED);
        JButton showAllButton = createButton("Mostrar Todos", Color.GREEN);
        JButton exitButton = createButton("Salir", Color.LIGHT_GRAY);

        // Agregar botones al panel
        buttonPanel.add(addCarButton);
        buttonPanel.add(addBikeButton);
        buttonPanel.add(addMotoButton);
        buttonPanel.add(editVehicleButton);
        buttonPanel.add(deleteVehicleButton);
        buttonPanel.add(showAllButton);
        buttonPanel.add(exitButton);

        mainPanel.add(buttonPanel, BorderLayout.WEST);

        // Área de visualización de vehículos
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(displayArea);

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Agregar panel principal al frame
        add(mainPanel);

        // Acción de botones
        addCarButton.addActionListener(e -> agregarCarro());
        addBikeButton.addActionListener(e -> agregarBici());
        addMotoButton.addActionListener(e -> agregarMoto());
        editVehicleButton.addActionListener(e -> editarVehiculo());
        deleteVehicleButton.addActionListener(e -> eliminarVehiculo());
        showAllButton.addActionListener(e -> mostrarTodos());
        exitButton.addActionListener(e -> System.exit(0));
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        return button;
    }

    private void agregarCarro() {
        JTextField nombreField = new JTextField();
        JTextField cedulaField = new JTextField();
        JTextField marcaRadioField = new JTextField();
        JTextField modeloField = new JTextField();
        JTextField marcaField = new JTextField();
        JTextField placaField = new JTextField();
        JTextField tamanioField = new JTextField();

        Object[] message = {
                "Nombre del conductor:", nombreField,
                "Cédula del conductor:", cedulaField,
                "Marca del radio:", marcaRadioField,
                "Modelo del carro:", modeloField,
                "Marca del carro:", marcaField,
                "Placa del carro:", placaField,
                "Tamaño del carro:", tamanioField,
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Agregar Carro", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            CarroDTO nuevoCarro = new CarroDTO(
                    nombreField.getText(),
                    Integer.parseInt(cedulaField.getText()),
                    marcaRadioField.getText(),
                    modeloField.getText(),
                    marcaField.getText(),
                    placaField.getText(),
                    Integer.parseInt(tamanioField.getText())
            );
            carroDAO.crear(nuevoCarro);
            mostrarTodos();
        }
    }

    private void agregarBici() {
        JTextField nombreField = new JTextField();
        JTextField cedulaField = new JTextField();
        JCheckBox canastaCheckBox = new JCheckBox("¿Tiene canasta?");
        JTextField numPedalesField = new JTextField();
        JTextField numRuedasField = new JTextField();
        JTextField numAsientosField = new JTextField();
        JTextField pesoField = new JTextField();

        Object[] message = {
                "Nombre del conductor:", nombreField,
                "Cédula del conductor:", cedulaField,
                "Número de pedales:", numPedalesField,
                "Número de ruedas:", numRuedasField,
                "Número de asientos:", numAsientosField,
                "Peso de la bici:", pesoField,
                canastaCheckBox,
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Agregar Bici", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            BiciDTO nuevaBici = new BiciDTO(
                    nombreField.getText(),
                    Integer.parseInt(cedulaField.getText()),
                    canastaCheckBox.isSelected(),
                    Integer.parseInt(numPedalesField.getText()),
                    Integer.parseInt(numRuedasField.getText()),
                    Integer.parseInt(numAsientosField.getText()),
                    Float.parseFloat(pesoField.getText())
            );
            biciDAO.crear(nuevaBici);
            mostrarTodos();
        }
    }

    private void agregarMoto() {
        JTextField nombreField = new JTextField();
        JTextField cedulaField = new JTextField();
        JTextField cilindrajeField = new JTextField();
        JCheckBox parrillaCheckBox = new JCheckBox("¿Tiene parrilla?");
        JTextField tipoSillonField = new JTextField();
        JTextField tamanioField = new JTextField();
        JTextField placaField = new JTextField();

        Object[] message = {
                "Nombre del conductor:", nombreField,
                "Cédula del conductor:", cedulaField,
                "Cilindraje de la moto:", cilindrajeField,
                parrillaCheckBox,
                "Tipo de sillón:", tipoSillonField,
                "Tamaño de la moto:", tamanioField,
                "Placa de la moto:", placaField,
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Agregar Moto", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            MotoDTO nuevaMoto = new MotoDTO(
                    nombreField.getText(),
                    Integer.parseInt(cedulaField.getText()),
                    Integer.parseInt(cilindrajeField.getText()),
                    parrillaCheckBox.isSelected(),
                    tipoSillonField.getText(),
                    Integer.parseInt(tamanioField.getText()),
                    placaField.getText()
            );
            motoDAO.crear(nuevaMoto);
            mostrarTodos();
        }
    }

    private void editarVehiculo() {
        String tipoVehiculo = JOptionPane.showInputDialog(this, "Tipo de vehículo a editar (Carro/Bici/Moto):");
        String posStr = JOptionPane.showInputDialog(this, "Posición del vehículo a editar:");
        int posicion = Integer.parseInt(posStr);

        switch (tipoVehiculo.toLowerCase()) {
            case "carro":
                editarCarro(posicion);
                break;
            case "bici":
                editarBici(posicion);
                break;
            case "moto":
                editarMoto(posicion);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Tipo de vehículo no reconocido.");
        }
    }

    private void editarCarro(int posicion) {
        JTextField nombreField = new JTextField();
        JTextField cedulaField = new JTextField();
        JTextField marcaRadioField = new JTextField();
        JTextField modeloField = new JTextField();
        JTextField marcaField = new JTextField();
        JTextField placaField = new JTextField();
        JTextField tamanioField = new JTextField();

        Object[] message = {
                "Nuevo nombre del conductor:", nombreField,
                "Nueva cédula del conductor:", cedulaField,
                "Nueva marca del radio:", marcaRadioField,
                "Nuevo modelo del carro:", modeloField,
                "Nueva marca del carro:", marcaField,
                "Nueva placa del carro:", placaField,
                "Nuevo tamaño del carro:", tamanioField,
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Editar Carro", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            CarroDTO carroActualizado = new CarroDTO(
                    nombreField.getText(),
                    Integer.parseInt(cedulaField.getText()),
                    marcaRadioField.getText(),
                    modeloField.getText(),
                    marcaField.getText(),
                    placaField.getText(),
                    Integer.parseInt(tamanioField.getText())
            );
            carroDAO.actualizar(posicion, carroActualizado);
            mostrarTodos();
        }
    }

    private void editarBici(int posicion) {
        JTextField nombreField = new JTextField();
        JTextField cedulaField = new JTextField();
        JCheckBox canastaCheckBox = new JCheckBox("¿Tiene canasta?");
        JTextField numPedalesField = new JTextField();
        JTextField numRuedasField = new JTextField();
        JTextField numAsientosField = new JTextField();
        JTextField pesoField = new JTextField();

        Object[] message = {
                "Nuevo nombre del conductor:", nombreField,
                "Nueva cédula del conductor:", cedulaField,
                "Nuevo número de pedales:", numPedalesField,
                "Nuevo número de ruedas:", numRuedasField,
                "Nuevo número de asientos:", numAsientosField,
                "Nuevo peso de la bici:", pesoField,
                canastaCheckBox,
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Editar Bici", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            BiciDTO biciActualizada = new BiciDTO(
                    nombreField.getText(),
                    Integer.parseInt(cedulaField.getText()),
                    canastaCheckBox.isSelected(),
                    Integer.parseInt(numPedalesField.getText()),
                    Integer.parseInt(numRuedasField.getText()),
                    Integer.parseInt(numAsientosField.getText()),
                    Float.parseFloat(pesoField.getText())
            );
            biciDAO.actualizar(posicion, biciActualizada);
            mostrarTodos();
        }
    }

    private void editarMoto(int posicion) {
        JTextField nombreField = new JTextField();
        JTextField cedulaField = new JTextField();
        JTextField cilindrajeField = new JTextField();
        JCheckBox parrillaCheckBox = new JCheckBox("¿Tiene parrilla?");
        JTextField tipoSillonField = new JTextField();
        JTextField tamanioField = new JTextField();
        JTextField placaField = new JTextField();

        Object[] message = {
                "Nuevo nombre del conductor:", nombreField,
                "Nueva cédula del conductor:", cedulaField,
                "Nuevo cilindraje de la moto:", cilindrajeField,
                parrillaCheckBox,
                "Nuevo tipo de sillón:", tipoSillonField,
                "Nuevo tamaño de la moto:", tamanioField,
                "Nueva placa de la moto:", placaField,
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Editar Moto", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            MotoDTO motoActualizada = new MotoDTO(
                    nombreField.getText(),
                    Integer.parseInt(cedulaField.getText()),
                    Integer.parseInt(cilindrajeField.getText()),
                    parrillaCheckBox.isSelected(),
                    tipoSillonField.getText(),
                    Integer.parseInt(tamanioField.getText()),
                    placaField.getText()
            );
            motoDAO.actualizar(posicion, motoActualizada);
            mostrarTodos();
        }
    }

    private void eliminarVehiculo() {
        String tipoVehiculo = JOptionPane.showInputDialog(this, "Tipo de vehículo a eliminar (Carro/Bici/Moto):");
        String posStr = JOptionPane.showInputDialog(this, "Posición del vehículo a eliminar:");
        int posicion = Integer.parseInt(posStr);

        boolean resultado = false;
        switch (tipoVehiculo.toLowerCase()) {
            case "carro":
                resultado = carroDAO.eliminar(posicion);
                break;
            case "bici":
                resultado = biciDAO.eliminar(posicion);
                break;
            case "moto":
                resultado = motoDAO.eliminar(posicion);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Tipo de vehículo no reconocido.");
                return;
        }

        if (resultado) {
            JOptionPane.showMessageDialog(this, "Vehículo eliminado exitosamente.");
            mostrarTodos();
        } else {
            JOptionPane.showMessageDialog(this, "Error al eliminar el vehículo. Verifique la posición.");
        }
    }

    private void mostrarTodos() {
        displayArea.setText("");
        displayArea.append("Carros:\n");
        displayArea.append(carroDAO.mostrar() + "\n");
        displayArea.append("Bicicletas:\n");
        displayArea.append(biciDAO.mostrar() + "\n");
        displayArea.append("Motos:\n");
        displayArea.append(motoDAO.mostrar() + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainView gui = new MainView();
            gui.setVisible(true);
        });
    }
}
