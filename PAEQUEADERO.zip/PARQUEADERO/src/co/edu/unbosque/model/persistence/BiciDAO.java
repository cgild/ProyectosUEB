package co.edu.unbosque.model.persistence;

import co.edu.ubosque.model.BiciDTO;
import co.edu.unbosque.util.structure.MyLinkedList;
import co.edu.unbosque.util.structure.Node;

public class BiciDAO implements CRUDOperation {

    private MyLinkedList<BiciDTO> listaBicis;

    public BiciDAO() {
        listaBicis = new MyLinkedList<>();
    }

    @Override
    public void crear(Object o) {
        BiciDTO nuevaBici = (BiciDTO) o;
        listaBicis.add(nuevaBici);
    }

    @Override
    public boolean eliminar(int posicion) {
        if (posicion < 0 || posicion >= listaBicis.size()) {
            return false;
        }
        if (posicion == 0) {
            listaBicis.extract();
        } else {
            Node<BiciDTO> previousNode = listaBicis.get(posicion - 1);
            if (previousNode != null) {
                listaBicis.extract(previousNode);
            }
        }
        return true;
    }

    @Override
    public boolean actualizar(int posicion, Object o) {
        if (posicion < 0 || posicion >= listaBicis.size()) {
            return false;
        } else {
            BiciDTO nuevaBici = (BiciDTO) o;
            listaBicis.extract(listaBicis.get(posicion)); // Elimina la bici actual en la posición
            listaBicis.add(nuevaBici); // Agrega la nueva bici en la misma posición
        }
        return true;
    }

    @Override
    public String mostrar() {
        Node<BiciDTO> current = listaBicis.getFirst();
        StringBuilder result = new StringBuilder();
        while (current != null) {
            result.append(current.getInfo()).append("\n");
            current = current.getNext();
        }
        return result.length() > 0 ? result.toString() : "No se encuentra esa bici.";
    }

    // Métodos adicionales para acceso
    public int size() {
        return listaBicis.size();
    }

    public Node<BiciDTO> getNode(int posicion) {
        return listaBicis.get(posicion);
    }
}
