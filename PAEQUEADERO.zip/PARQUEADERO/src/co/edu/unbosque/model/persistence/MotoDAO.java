package co.edu.unbosque.model.persistence;

import co.edu.ubosque.model.MotoDTO;
import co.edu.unbosque.util.structure.MyLinkedList;
import co.edu.unbosque.util.structure.Node;

public class MotoDAO implements CRUDOperation {

    private MyLinkedList<MotoDTO> listaMotos;

    public MotoDAO() {
        listaMotos = new MyLinkedList<>();
    }

    @Override
    public void crear(Object o) {
        MotoDTO nuevo = (MotoDTO) o;
        listaMotos.add(nuevo);
    }

    @Override
    public boolean eliminar(int posicion) {
        if (posicion < 0 || posicion >= listaMotos.size()) {
            return false;
        }
        if (posicion == 0) {
            listaMotos.extract();
        } else {
            Node<MotoDTO> previousNode = listaMotos.get(posicion - 1);
            if (previousNode != null) {
                listaMotos.extract(previousNode);
            }
        }
        return true;
    }

    @Override
    public boolean actualizar(int posicion, Object o) {
        if (posicion < 0 || posicion >= listaMotos.size()) {
            return false;
        } else {
            MotoDTO nuevaMoto = (MotoDTO) o;
            listaMotos.print(posicion); // Esto puede no ser necesario
            listaMotos.add(nuevaMoto);
        }
        return true;
    }

    @Override
    public String mostrar() {
        Node<MotoDTO> current = listaMotos.getFirst();
        StringBuilder result = new StringBuilder();
        while (current != null) {
            result.append(current.getInfo()).append("\n");
            current = current.getNext();
        }
        return result.length() > 0 ? result.toString() : "No se encuentra esa moto.";
    }

    // Métodos adicionales para acceso
    public int size() {
        return listaMotos.size();
    }

    public Node<MotoDTO> getNode(int posicion) {
        return listaMotos.get(posicion);
    }
}
