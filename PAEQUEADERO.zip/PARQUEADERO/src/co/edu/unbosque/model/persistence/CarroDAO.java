package co.edu.unbosque.model.persistence;

import co.edu.ubosque.model.CarroDTO;
import co.edu.unbosque.util.structure.MyLinkedList;
import co.edu.unbosque.util.structure.Node;

public class CarroDAO implements CRUDOperation {

    private MyLinkedList<CarroDTO> listaCarros;

    public CarroDAO() {
        listaCarros = new MyLinkedList<>();
    }

    @Override
    public void crear(Object o) {
        CarroDTO nuevoCarro = (CarroDTO) o;
        listaCarros.add(nuevoCarro);
    }

    @Override
    public boolean eliminar(int posicion) {
        if (posicion < 0 || posicion >= listaCarros.size()) {
            return false;
        }
        if (posicion == 0) {
            listaCarros.extract();
        } else {
            Node<CarroDTO> previousNode = listaCarros.get(posicion - 1);
            if (previousNode != null) {
                listaCarros.extract(previousNode);
            }
        }
        return true;
    }

    @Override
    public boolean actualizar(int posicion, Object o) {
        if (posicion < 0 || posicion >= listaCarros.size()) {
            return false;
        } else {
            CarroDTO nuevoCarro = (CarroDTO) o;
            listaCarros.extract(listaCarros.get(posicion)); // Elimina el carro actual en la posición
            listaCarros.add(nuevoCarro); // Agrega el nuevo carro en la misma posición
        }
        return true;
    }

    @Override
    public String mostrar() {
        Node<CarroDTO> current = listaCarros.getFirst();
        StringBuilder result = new StringBuilder();
        while (current != null) {
            result.append(current.getInfo()).append("\n");
            current = current.getNext();
        }
        return result.length() > 0 ? result.toString() : "No se encuentra ese carro.";
    }

    // Métodos adicionales para acceso
    public int size() {
        return listaCarros.size();
    }

    public Node<CarroDTO> getNode(int posicion) {
        return listaCarros.get(posicion);
    }
}
