package co.edu.unbosque.model.persistence;

public interface CRUDOperation {	
	public void crear(Object o);
	public boolean eliminar(int posicion);
	public boolean actualizar(int posicion, Object o);
	public String mostrar();
}
