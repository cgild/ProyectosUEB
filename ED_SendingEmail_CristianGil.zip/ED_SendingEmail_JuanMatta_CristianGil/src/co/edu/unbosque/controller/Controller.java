package co.edu.unbosque.controller;

import co.edu.unbosque.model.EmailModel;
import co.edu.unbosque.view.Console;

public class Controller {
    private Console con;
    private EmailModel model;

    public Controller() {
        con = new Console();
        model = new EmailModel();
    }

    public void run() {
        int opcion = -1;
        while (opcion != 4) {
            con.impresionConSalto("--- Bienvenido al aplicativo de Latencia ---");
            con.impresionConSalto("Digite una opcion:");
            con.impresionConSalto("1. Agregar conexiones entre servidores");
            con.impresionConSalto("2. Calcular la latencia minima");
            con.impresionConSalto("3. Reiniciar los servidores");
            con.impresionConSalto("4. Salir");
            opcion = con.leerEntero();
            con.quemarLinea();

            switch (opcion) {
                case 1:
                    addConnections();
                    break;
                case 2:
                    calculateMinLatency();
                    break;
                case 3:
                    resetModel();
                    break;
                case 4:
                    con.impresionConSalto("Gracias por usar el programa. Feliz dia.");
                    break;
                default:
                    con.impresionConSalto("Error. Digite una opcion valida.");
            }
        }
    }

    private void addConnections() {
        con.impresionSinSalto("Digite el numero de servidores: ");
        int n = con.leerEntero();
        con.quemarLinea();

        con.impresionSinSalto("Digite el numero de conexiones: ");
        int m = con.leerEntero();
        con.quemarLinea();

        for (int i = 0; i < m; i++) {
            con.impresionSinSalto("Digite la conexion (servidor1 servidor2 latencia): ");
            int u = con.leerEntero();
            int v = con.leerEntero();
            int latency = con.leerEntero();
            con.quemarLinea();

            model.addEdge(u, v, latency);
        }
        con.impresionConSalto("Conexiones agregadas exitosamente.");
    }

    private void calculateMinLatency() {
        con.impresionSinSalto("Digite el ID del servidor de origen: ");
        int source = con.leerEntero();
        con.quemarLinea();

        con.impresionSinSalto("Digite el ID del servidor de destino: ");
        int target = con.leerEntero();
        con.quemarLinea();

        con.impresionSinSalto("Digite el numero total de servidores: ");
        int numServers = con.leerEntero();
        con.quemarLinea();

        int result = model.calculateMinLatency(source, target, numServers);
        if (result == Integer.MAX_VALUE) {
            con.impresionConSalto("Resultado: unreachable");
        } else {
            con.impresionConSalto("La latencia minima es: " + result + " ms");
        }
    }

    private void resetModel() {
        model.resetModel();
        con.impresionConSalto("Los servidores fueron reiniciados.");
    }
}