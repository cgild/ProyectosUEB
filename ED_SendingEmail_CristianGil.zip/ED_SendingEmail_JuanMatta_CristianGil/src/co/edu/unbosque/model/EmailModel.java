package co.edu.unbosque.model;

import java.util.HashMap;
import java.util.Map;

public class EmailModel {
    public static class Server {
        int id;
        Connection connection;

        Server(int id) {
            this.id = id;
        }
    }

    public static class Connection {
        Server target;
        int latency;
        Connection nextConnection;

        Connection(Server target, int latency) {
            this.target = target;
            this.latency = latency;
        }
    }

    private Map<Integer, Server> servers;
    private int minLatency;

    public EmailModel() {
        servers = new HashMap<>();
    }

    public void addEdge(int u, int v, int latency) {
        servers.putIfAbsent(u, new Server(u));
        servers.putIfAbsent(v, new Server(v));

        Server serverU = servers.get(u);
        Server serverV = servers.get(v);

        Connection connection1 = new Connection(serverV, latency);
        connection1.nextConnection = serverU.connection;
        serverU.connection = connection1;

        Connection connection2 = new Connection(serverU, latency);
        connection2.nextConnection = serverV.connection;
        serverV.connection = connection2;
    }

    private void findShortestPath(Server current, Server target, int accumulatedLatency, boolean[] visited) {
        if (visited[current.id]) return;

        visited[current.id] = true;

        if (current == target) {
            if (accumulatedLatency < minLatency) {
                minLatency = accumulatedLatency;
            }
            visited[current.id] = false;
            return;
        }

        Connection connection = current.connection;
        while (connection != null) {
            findShortestPath(connection.target, target, accumulatedLatency + connection.latency, visited);
            connection = connection.nextConnection;
        }

        visited[current.id] = false;
    }

    public int calculateMinLatency(int sourceId, int targetId, int numServers) {
        minLatency = Integer.MAX_VALUE;
        boolean[] visited = new boolean[numServers];
        Server source = servers.get(sourceId);
        Server target = servers.get(targetId);

        if (source == null || target == null) {
            return Integer.MAX_VALUE;
        }

        findShortestPath(source, target, 0, visited);
        return minLatency;
    }

    public void resetModel() {
        servers.clear();
    }
}