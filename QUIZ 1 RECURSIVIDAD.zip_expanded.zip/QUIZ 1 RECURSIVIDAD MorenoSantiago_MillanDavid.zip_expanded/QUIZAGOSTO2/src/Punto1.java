import java.util.Scanner;

public class Punto1 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		System.out.print("Digite un número: ");
		int numero = s.nextInt();
		imprimirPartesNumero(numero, 1);
		s.close();
	}

	public static void imprimirPartesNumero(int numero, int factor) {
		if (factor > 100000000) {
			return;
		}

		int parte = (numero / factor) % 10;

		if (factor == 1) {
			System.out.println("Unidades: " + parte);
		} else if (factor == 10) {
			System.out.println("Decenas: " + parte);
		} else if (factor == 100) {
			System.out.println("Centenas: " + parte);
		} else if (factor == 1000) {
			System.out.println("Miles: " + parte);
		} else if (factor == 1000000) {
			System.out.println("Millones: " + parte);
		} else if (factor == 100000000) {
			System.out.println("Centenas de millon: " + parte);
		}
		imprimirPartesNumero(numero, factor * 10);
	}
}
