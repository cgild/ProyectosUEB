import java.util.Scanner;

public class Punto3 {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);

		System.out.println("Digite un número entero: ");
		int numero = s.nextInt();
		contarDivisiones(numero);
		s.nextLine();

		if (numero <= 0) {
			System.out.println("El número entero debe ser mayor que cero");
		}

		int resultado = contarDivisiones(numero);
		System.out.println("Cantidad de divisiones para llegar a 1: " + resultado);

		s.close();
	}

	public static int contarDivisiones(int numero) {

		if (numero <= 1) {
			return 0;
		}
		return 1 + contarDivisiones(numero / 2);
	}
}
