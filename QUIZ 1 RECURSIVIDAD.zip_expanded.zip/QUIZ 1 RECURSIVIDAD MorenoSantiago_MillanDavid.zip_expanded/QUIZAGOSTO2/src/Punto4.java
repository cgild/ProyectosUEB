import java.util.Scanner;

public class Punto4 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);

		System.out.print("Digite el número de nombres que va a ingresar: ");
		int cantidadNombres = s.nextInt();
		s.nextLine();

		if (cantidadNombres <= 0) {
			System.out.println("El número de nombres debe ser mayor que cero");
		}

		String[] nombres = new String[cantidadNombres];

		for (int i = 0; i < cantidadNombres; i++) {
			System.out.print("Digite el nombre #" + (i + 1) + ": ");
			nombres[i] = s.nextLine();
		}
		String nombreMasCorto = encontrarNombreMasCorto(nombres, 0, nombres[0]);
        System.out.println("El nombre más corto es: " + nombreMasCorto);

		s.close();
	}

	public static String encontrarNombreMasCorto(String[] nombres, int index, String nombreMasCorto) {
		if (index >= nombres.length) {
			return nombreMasCorto;
		}

		if (nombres[index].length() < nombreMasCorto.length()) {
			nombreMasCorto = nombres[index];
		}

		return encontrarNombreMasCorto(nombres, index + 1, nombreMasCorto);
	}
}
