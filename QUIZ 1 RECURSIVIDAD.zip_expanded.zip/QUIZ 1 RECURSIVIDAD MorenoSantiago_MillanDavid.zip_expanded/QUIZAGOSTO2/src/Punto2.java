import java.util.Scanner;

public class Punto2 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);

		System.out.print("Cuántas cadenas desea contar? ");
		int numCadenas = s.nextInt();
		s.nextLine();

		for (int i = 0; i < numCadenas; i++) {
			System.out.print("Digite la cadena #" + (i + 1) + ": ");
			String cadena = s.nextLine();

			int cantidadEspacios = contarEspacios(cadena);
			System.out.println("La cadena \"" + cadena + "\" tiene " + cantidadEspacios + " espacios.");
		}
		s.close();
	}

	public static int contarEspacios(String cadena) {

		if (cadena.isEmpty()) {
			return 0;
		}
		if (cadena.charAt(0) == ' ') {
			return 1 + contarEspacios(cadena.substring(1));
		} else {
			return contarEspacios(cadena.substring(1));
		}
	}
}